// import React from 'react';
// import { Routes, Route } from 'react-router-dom';
// import AdminLogin from './AdminLogin';
// import AdminRegister from './AdminRegister';

// function AdminAuth() {
//   return (
//     <Routes>
//       <Route path="/admin/login" element={<AdminLogin />} />
//       <Route path="/admin/register" element={<AdminRegister />} />
//     </Routes>
//   );
// }

// export default AdminAuth;
