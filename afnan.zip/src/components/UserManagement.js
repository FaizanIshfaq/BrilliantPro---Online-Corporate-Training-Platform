import React from 'react';

const UserManagement = () => {
  return (
    <div>
      <h2>User Management</h2>
      <p>List of registered users</p>
    </div>
  );
};

export default UserManagement;
