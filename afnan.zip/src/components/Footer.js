import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p>&copy; 2023 BrilliantPro LMS</p>
    </footer>
  );
};

export default Footer;
