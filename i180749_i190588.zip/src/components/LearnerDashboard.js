import React from 'react';

const LearnerDashboard = () => {
  return (
    <div>
      <h2>Learner Dashboard</h2>
      <p>List of enrolled courses and progress</p>
    </div>
  );
};

export default LearnerDashboard;
