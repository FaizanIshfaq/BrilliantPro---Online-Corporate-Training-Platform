import React from 'react';

const CourseManagement = () => {
  return (
    <div>
      <h2>Course Management</h2>
      <p>List of available courses</p>
    </div>
  );
};

export default CourseManagement;
